#This is a open source project.
# Python 3
These files are mainly intended to accompany my series of YouTube tutorial videos here, 
https://www.youtube.com/user/joejamesusa
and are mainly intended for educational purposes.
You are invited to subscribe to my video channel-Joe James, and to download and use any code in 
this Python repository, according to the MIT License. 
Feel free to post any comments on my YouTube channel.
i am very happy to see you there on my you tube channel. excited!!!!!!!!!
## Subscribe to my channel for more tutorial videos. 

This source codes are easy to understand and reliable for self study and you will learn them easily, try to practice more coding by making algorithms yourself and you can be better python programmer and remember "Try to learn something about everything and everything about something".

Thank you for reviewing my repositories and keep practicing.
Joe James.
Fremont, CA.
Copyright (C) 2015-2020, Joe James

## Happy coding guys!😀
